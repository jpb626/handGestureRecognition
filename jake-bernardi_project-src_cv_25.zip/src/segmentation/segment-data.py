#!/usr/bin/env python3
import os
import cv2
import mediapipe as mp
import numpy as np

# Initialize Mediapipe Hands solution.
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils

def extract_hand_skeleton_mask(image, hands):
    """
    Uses Mediapipe to detect hand landmarks and draws the hand skeleton
    (landmarks and connections) on a blank mask.
    Returns a strictly binary mask (0 or 255) where the hand skeleton is white.
    """
    # Convert image to RGB as required by Mediapipe.
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    results = hands.process(image_rgb)
    
    # Create a blank single-channel mask.
    mask = np.zeros(image.shape[:2], dtype=np.uint8)
    
    if results.multi_hand_landmarks:
        h, w = image.shape[:2]
        for hand_landmarks in results.multi_hand_landmarks:
            # Draw landmarks and connections on a temporary image.
            temp_img = np.zeros((h, w, 3), dtype=np.uint8)
            mp_drawing.draw_landmarks(
                temp_img,
                hand_landmarks,
                mp_hands.HAND_CONNECTIONS,
                landmark_drawing_spec=mp_drawing.DrawingSpec(color=(255, 255, 255), thickness=2, circle_radius=2),
                connection_drawing_spec=mp_drawing.DrawingSpec(color=(255, 255, 255), thickness=2)
            )
            # Convert the drawing to grayscale.
            temp_gray = cv2.cvtColor(temp_img, cv2.COLOR_BGR2GRAY)
            # Threshold to obtain a binary mask.
            _, temp_binary = cv2.threshold(temp_gray, 50, 255, cv2.THRESH_BINARY)
            mask = cv2.bitwise_or(mask, temp_binary)
    
    # Ensure the output is strictly binary.
    _, binary_mask = cv2.threshold(mask, 127, 255, cv2.THRESH_BINARY)
    return binary_mask

def process_image_file(image_path, hands):
    """
    Reads an image, resizes it to 640x480, runs the segmentation algorithm,
    and writes the resulting binary mask back to the same file.
    """
    image = cv2.imread(image_path)
    if image is None:
        print(f"Error: Could not read image from {image_path}")
        return False
    
    # Resize the image to 640x480.
    resized_image = cv2.resize(image, (640, 480))
    
    # Get the binary hand skeleton mask.
    mask = extract_hand_skeleton_mask(resized_image, hands)
    
    # Overwrite the original image with the binary mask.
    success = cv2.imwrite(image_path, mask)
    if not success:
        print(f"Error: Could not write segmented image to {image_path}")
    return success

def main():
    # Base directory for the dataset.
    base_dir = os.path.join("..", "..", "segmented-data", "leapGestRecog")
    # Subject folders are "00" to "09".
    subjects = [f"{i:02d}" for i in range(10)]
    # Image folders to process.
    image_folders = ["01_palm", "03_fist", "05_thumb", "06_index", "07_ok"]
    
    # Initialize Mediapipe Hands in static image mode.
    with mp_hands.Hands(
         min_detection_confidence=0.6,
         min_tracking_confidence=0.6,
         max_num_hands=1,
         static_image_mode=True) as hands:
        
        # Loop through each subject folder.
        for subject in subjects:
            for folder in image_folders:
                folder_path = os.path.join(base_dir, subject, folder)
                if not os.path.isdir(folder_path):
                    print(f"Folder not found: {folder_path}")
                    continue
                # Process each PNG file in the folder.
                for filename in os.listdir(folder_path):
                    if filename.lower().endswith(".png"):
                        image_path = os.path.join(folder_path, filename)
                        if process_image_file(image_path, hands):
                            print(f"Processed: {image_path}")
                        else:
                            print(f"Failed: {image_path}")

if __name__ == '__main__':
    main()

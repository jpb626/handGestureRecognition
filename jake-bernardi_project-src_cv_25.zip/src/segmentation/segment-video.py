#!/usr/bin/env python3
import cv2
import mediapipe as mp
import numpy as np

# Initialize Mediapipe Hands solution.
mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils

def extract_hand_skeleton_mask(image, hands):
    """
    Uses Mediapipe to detect hand landmarks and draws the hand skeleton
    (landmarks and connections) on a blank mask.
    The result is a strictly binary mask (0 or 255) where the hand skeleton is white.
    """
    # Convert image to RGB as required by Mediapipe.
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    results = hands.process(image_rgb)
    
    # Create a blank single-channel mask.
    mask = np.zeros(image.shape[:2], dtype=np.uint8)
    
    if results.multi_hand_landmarks:
        h, w = image.shape[:2]
        for hand_landmarks in results.multi_hand_landmarks:
            # Create a temporary color image to draw the skeleton.
            temp_img = np.zeros((h, w, 3), dtype=np.uint8)
            mp_drawing.draw_landmarks(
                temp_img,
                hand_landmarks,
                mp_hands.HAND_CONNECTIONS,
                landmark_drawing_spec=mp_drawing.DrawingSpec(color=(255, 255, 255), thickness=2, circle_radius=2),
                connection_drawing_spec=mp_drawing.DrawingSpec(color=(255, 255, 255), thickness=2)
            )
            # Convert drawn skeleton to grayscale.
            temp_gray = cv2.cvtColor(temp_img, cv2.COLOR_BGR2GRAY)
            # Threshold to obtain a binary mask.
            _, temp_binary = cv2.threshold(temp_gray, 50, 255, cv2.THRESH_BINARY)
            # Combine with the main mask.
            mask = cv2.bitwise_or(mask, temp_binary)
    
    # Ensure the output is strictly binary.
    _, binary_mask = cv2.threshold(mask, 127, 255, cv2.THRESH_BINARY)
    return binary_mask

def main():
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    
    if not cap.isOpened():
        print("Error: Could not open webcam")
        return
    
    with mp_hands.Hands(
            min_detection_confidence=0.6,
            min_tracking_confidence=0.6,
            max_num_hands=1,
            static_image_mode=False) as hands:
        while True:
            ret, frame = cap.read()
            if not ret:
                print("Error: Could not read frame")
                break
            
            # Extract the hand skeleton mask.
            skeleton_mask = extract_hand_skeleton_mask(frame, hands)
            
            # Optionally, operate only on the skeleton pixels.
            # For instance, to slightly thicken the skeleton, uncomment below:
            # kernel = np.ones((3, 3), np.uint8)
            # skeleton_mask = cv2.dilate(skeleton_mask, kernel, iterations=1)
            
            cv2.imshow("Original", frame)
            cv2.imshow("Hand Skeleton Mask (BW)", skeleton_mask)
            
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        
    cap.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
